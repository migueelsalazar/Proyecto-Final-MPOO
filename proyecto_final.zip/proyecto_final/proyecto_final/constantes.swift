/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/


//
//  constantes.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/13/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

//En este archivo se almacena la constante que permite acceder a la página principal


import Foundation


struct  constantes {
    // Par accesar más rápido a las variables las declaramos como estáticas
    static let pagPrin = "principal"
}




