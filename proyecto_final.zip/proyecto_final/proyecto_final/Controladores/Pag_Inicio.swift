/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/






//
//  Pag_Inicio.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/11/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit


//Esta vista sólo funciona como contenedor de labels
//Es una Página de inicio

class Pag_Inicio: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
