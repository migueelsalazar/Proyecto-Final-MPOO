/*
 
        Universidad Nacional Autónoma de México.
            Facultad de Ingeniería.
        División de Ingeniería Eléctrica.
 
    Modelos de Programación Orientada a Objetos.
 
 
 
                --Proyecto Final--
 
 
 
     
     Alumnos:
     López Salazar Miguel Ángel
     Rodríguez Ortíz Rodrigo
     
 
     Profesor: Ing. Germán Santos Jaimes

     
     Contacto: miguelangelsalazar076@gmail.com
     
 */




//  ViewController.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/11/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var registro: UIButton!
    
    @IBOutlet weak var entrar: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        //Función prototipo
        editarElementos ()
        
        
        // Do any additional setup after loading the view.
    }
    //Crear funcion que estiliza los botones
    func editarElementos () {
        
        edicion.styleFilledButton(registro)
        edicion.styleHollowButton(entrar)
        
        
    }

}

