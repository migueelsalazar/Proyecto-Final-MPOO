/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/






//
//  TableViewController.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/20/19.
//  Copyright © 2019 ioslab. All rights reserved.
//


import UIKit
import FirebaseDatabase


//Conección a la base de datos
var ref: DatabaseReference?
var dataBaseHandle:DatabaseHandle?

var llave:String?
var valor:String!
//Array de palabras

var palabras = [String]()
var significado = [String]()

var control = 0 //Variable que lleva el control que que renglón se seleccionó

//let nuevoPost = dataBaseHandle

//var nuevoPost = palabras.count

class TableViewController: UITableViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        palabras = [""]
        significado = [""]
        
        
        //Asignación de la base de datos
        ref = Database.database().reference()
        
        
        //Conectar la base de datos
        
        dataBaseHandle = ref?.child("Palabras").observe(.childAdded, with: { (snapshot) in
            //Código ejecutable cuando se agrege una nueva palabra a la base de datos
        
            
            llave = snapshot.key
            valor = snapshot.value! as? String
            
       
            //Meter los datos de Firebase a los arreglos que controlan el TableView
            palabras.append(llave!)
            significado.append(valor)
            self.tableView.reloadData()
            
            
            
            //Recargar los datos de Firebase
            
           if dataBaseHandle != nil{
                
            
                
                self.tableView.reloadData()
            }
            
            
          
            
        
            
        
        })
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of row
        
        
        //Regresar tantos renglones como elementos existan en el array
        return palabras.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
        
        //Cambiar el texto de los renglones del TableViewController por el las palabras
        cell.textLabel?.text = palabras [indexPath.row]
        

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //Saber que renglón se ha seleccionado y por defecto saber que índice del array es seleccionado
        control = indexPath.row
        //Cambiar de vista a Palabras.swift
        performSegue(withIdentifier: "segue", sender: self)
        
        
        
    }

  
    // El bloque de ejecución siguiente se dará en Palabras.swift


    
  
    
    
    
}
