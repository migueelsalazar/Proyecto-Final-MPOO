/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/





//  Vista1.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/11/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

import UIKit
import Firebase
//Libreria de Firebase que nos permite realizar la autenticación
import FirebaseAuth





//Vista: Registros
class Vista1: UIViewController {
    
//Conectar elementos
    
    @IBOutlet weak var nombreTextField: UITextField!
    
    @IBOutlet weak var apellidoTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var contraTextField: UITextField!
    
    @IBOutlet weak var registroButton: UIButton!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    
    
override func viewDidLoad() {
        super.viewDidLoad()

        //Función prototitpo encargada de estilizar
        editarElementos()
        
        
    }
    
    //Crear funcion que estiliza los botones
    func editarElementos (){
        //Desactivar mensaje de error
        errorLabel.alpha = 0
        //Uso de los metodos de edicion.swift 
        edicion.styleTextField(nombreTextField)
        edicion.styleTextField(apellidoTextField)
        edicion.styleTextField(emailTextField)
        edicion.styleTextField(contraTextField)
        edicion.styleFilledButton(registroButton)
        
        
    }
    
    /* Esta función tiene como objetivo validar si se han llenado todos los campos de registro
     y si la contraseña es segura. Para la contraseña se usará una función del archivo edicion.swift que nos permite verificar si la contraseña dada es fuerte mediante el uso de una expresion regular
     */
    
    func validacion () -> String? {
        //Checar si se ha llenado el nombre
        if nombreTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Por favor rellene todos los campos"
            
        }
        //Checar si se ha llenado el apellido
        if apellidoTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Por favor rellene todos los campos"
            
        }
        //Checar si se ha dado un correo
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == ""{
            
            return "Por favor rellene todos los campos"
        }
        //Checar si se ha dado una contraseña
        if contraTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Por favor rellene todos los campos"
        }
        
        let contra = contraTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //Checar si la contraseña es segura en base al booleano que regresa
        if edicion.contraFuerte(contra) == true {
            
            
         return "Pon una contraseña mas fuerte, al menos 8 caracteres y un numero"
            
        }
        
        
        
        
        
        //Este valor nos será de ayuda para reconocer si se han validado correctamente los datos
        return nil
    }

    
    //Crear usuario
    @IBAction func registroTap(_ sender: Any) {
        
        let error = validacion()
       
        //Si no regresa nulo (como la función marca) significa que hubo un error en la validación
        if error != nil {
            
            //Accionar la función de error
            errorOcurrido(error!)
            
        }
        
        //Si regresa nulo quiere decir que no hubo problemas, entonces se crea el usuario y se cambia a la siguiente página
        else {
            
            //Crear vesiones limpiras para la base de datos
            let nombre = nombreTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let apellido = apellidoTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let correo = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let contraseña = contraTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            
            //Método que permite  crear un usuario en Firebase, "resultado" almacenará el UID proporcionado por Firebase
            Auth.auth().createUser(withEmail: correo, password: contraseña) { (resultado, err) in
                
                
                //Caso: Error de autenticación
                if err != nil {
                    
                    self.errorOcurrido("Hubo un error en la validación")
                    
                }
                    
                //Caso: Sin errores
                else {
                    //Creación en base de datos (Importado de la documentación de Firebase)
                    let db = Firestore.firestore()
                    db.collection("Usuarios").addDocument(data: ["Nombre": nombre, "Apellido": apellido,"UID": resultado!.user.uid ]) { (error) in
                        if error != nil {
                            
                            self.errorOcurrido("Error en la base de datos")
                            
                        }
                        
                      //Cambiar de vista
                        
                        self.cambioVista()
                        
                        
                    }
                    
                    
                }
                
                
                
                
            }
            
        }
        
    }
    
    //Función encargada de mostrar el Label de error y modificar su contenido
    func errorOcurrido (_ mensaje: String ) {
        
                  errorLabel.text = mensaje
                  errorLabel.alpha = 1
        
    }
        
    //Función que nos cambia a la vista principal una vez que se ha ingresado correctamente
    func cambioVista(){
        
        let pagInicio = storyboard?.instantiateViewController(identifier: constantes.pagPrin) as?
        Pag_Inicio
        view.window?.rootViewController = pagInicio
        view.window?.makeKeyAndVisible()
        
    }
    
    
}
