/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/



//
//  Palabras.swift
//  
//
//  Created by 2020-1 on 11/20/19.
//

import UIKit


class Palabras: UIViewController {

    //Conectar elementos
    @IBOutlet weak var Palabra: UILabel!
    
    @IBOutlet weak var Significado: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       //Cambiar los datos de cada palabra de acuerdo a la palabra seleccionada
        Palabra.text = palabras [control]
        
        Significado.text = significado [control]
    
        
        
    }
    
    
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
