/*

       Universidad Nacional Autónoma de México.
           Facultad de Ingeniería.
       División de Ingeniería Eléctrica.

   Modelos de Programación Orientada a Objetos.



               --Proyecto Final--



    
    Alumnos:
    López Salazar Miguel Ángel
    Rodríguez Ortíz Rodrigo
    

    Profesor: Ing. Germán Santos Jaimes

    
    Contacto: miguelangelsalazar076@gmail.com
    
*/


//
//  Vista2.swift
//  proyecto_final
//
//  Created by 2020-1 on 11/11/19.
//  Copyright © 2019 ioslab. All rights reserved.
//

//Librerias utilizadas
import UIKit
import FirebaseAuth


class Vista2: UIViewController {

    
    //Conección de elementos
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var contraseñaTextField: UITextField!
    
    @IBOutlet weak var entrarButton: UIButton!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Función prototipo 
        editarElementos ()
        
    }
  
    func editarElementos () {
         //Desactivar mensaje de error
        errorLabel.alpha = 0
        //Uso de los metodos de edicion.swift 
        edicion.styleTextField(emailTextField)
        edicion.styleTextField(contraseñaTextField)
        edicion.styleFilledButton(entrarButton)
        
    }
    
    //Validar los datos del usuario
           func validacion () -> String? {
               
               if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                   //Mensaje de error
                   return "Por favor rellene todos los campos"
                   
               }
               
               if contraseñaTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
               
                
                //Mensaje de error
               return "Por favor rellene todos los campos"
               
               
               
               }
               
               
             return nil
           }
    
    
    
    
    @IBAction func entrarTap(_ sender: Any) {
        
       let error = validacion()
        
        if error != nil {
            
            errorOcurrido(error!)
            
        }
        
        else {
            
           //Crear versiones limpias de los datos
            
            let e_mail = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let contraseña = contraseñaTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            
            //Entrar a la base de datos
            
            Auth.auth().signIn(withEmail: e_mail, password: contraseña) { (result, error) in
                if error != nil{
                    //Mensaje de error
                    self.errorOcurrido("Datos erroneos")
                    
                    
                    
                }
                
                else {
                    //Si todo sale bien, se cambia de vista a Pag_Inicio.swift
                    self.cambioVista()
                    
                }
                
                
            }
            
            
            
            
        }
        
        
       
        
    }
    
    //Función que activa el error en el label.
    func errorOcurrido (_ mensaje: String ) {
        
                  errorLabel.text = mensaje
                  errorLabel.alpha = 1
        
    }
    
    //Funciòn que nos cambia de vista a Pag_Inicio.swift
    func cambioVista(){
        
        let pagInicio = storyboard?.instantiateViewController(identifier: constantes.pagPrin) as?
        Pag_Inicio
        view.window?.rootViewController = pagInicio
        view.window?.makeKeyAndVisible()
        
    }
    
}
